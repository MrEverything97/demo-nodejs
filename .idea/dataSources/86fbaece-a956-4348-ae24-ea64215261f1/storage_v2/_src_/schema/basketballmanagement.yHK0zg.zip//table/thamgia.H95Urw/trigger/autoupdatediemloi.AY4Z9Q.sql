create definer = root@localhost trigger AutoUpdateDiemLoi
    after insert
    on thamgia
    for each row
BEGIN 
		# only update when all reqs met: neu la doi nha
            ######## Rule: default all diem = 0, all loi = 0;
			UPDATE TranDau set DiemDN = DiemDN + NEW.SoDiem, SoLoiDN = SoLoiDN + NEW.SoLoi
            WHERE NEW.MaTD = TranDau.MaTD AND NEW.MaVong = TranDau.MaVong AND New.TenDoi = TranDau.DoiNha;
		
			# neu la doi khach
			update TranDau set DiemDK = DiemDK + NEW.SoDiem, SoLoiDK = SoLoiDK + New.SoLoi
            WHERE NEW.MaTD = TranDau.MaTD AND NEW.MaVong = TranDau.MaVong AND New.TenDoi = TranDau.DoiKhach;
END;

