create definer = root@localhost trigger ToiDa30CT1D
    after insert
    on cauthu
    for each row
BEGIN 
		DECLARE TongSoAo int;
		DECLARE MaxSoAo int;
        SET TongSoAo := 0;
        SET MaxSoAo := 30;
	
		SELECT COUNT(*) INTO TongSoAo
		FROM CauThu 
		WHERE CauThu.TenDoi = NEW.TenDoi;
		IF TongSoAo > MaxSoAo
			THEN BEGIN 
				signal sqlstate '45000' set message_text = 'My Trigger Error: Vuot Qua 30  cau thu moi doi! ';
            END;
		END if;
END;

