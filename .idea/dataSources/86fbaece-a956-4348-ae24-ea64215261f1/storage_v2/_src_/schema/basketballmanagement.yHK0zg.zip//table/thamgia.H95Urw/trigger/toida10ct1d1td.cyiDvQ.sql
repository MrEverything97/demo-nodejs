create definer = root@localhost trigger ToiDa10CT1D1TD
    after insert
    on thamgia
    for each row
BEGIN 
		DECLARE TongSoAo int;
		DECLARE MaxSoAo int;
        SET TongSoAo := 0;
        SET MaxSoAo := 10;
	
		SELECT COUNT(*) INTO TongSoAo
		FROM ThamGia
		WHERE ThamGia.MaVong = NEW.MaVong AND ThamGia.MaTD = NEW.MaTD AND ThamGia.TenDoi = NEW.TenDoi;
		IF TongSoAo > MaxSoAo
			THEN BEGIN 
				signal sqlstate '45000' set message_text = 'My Trigger Error: Vuot Qua 10  cau thu moi doi trong mot tran dau! ';
            END;
		END if;
END;

