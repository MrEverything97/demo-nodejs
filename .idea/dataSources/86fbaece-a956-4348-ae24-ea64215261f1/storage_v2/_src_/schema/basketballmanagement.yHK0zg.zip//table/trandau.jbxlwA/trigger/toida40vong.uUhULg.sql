create definer = root@localhost trigger ToiDa40Vong
    after insert
    on trandau
    for each row
BEGIN 
		DECLARE TongVong int;
		DECLARE MaxVong int;
        SET TongVong := 0;
        SET MaxVong := 40;
	
		SELECT COUNT(DISTINCT MaVong) INTO TongVong
		FROM TranDau;
		IF TongVong > MaxVong
			THEN BEGIN 
				signal sqlstate '45000' set message_text = 'My Trigger Error: Vuot Qua 40 vong tren 1 giai! ';
            END;
		END if;
END;

